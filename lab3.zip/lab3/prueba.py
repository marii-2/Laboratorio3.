name="angel"
from random import randrange
password="123"
def question(name,password,cat):
    try:
        usuario_file= open("usuario", "r")
    except:
        print("el archivo no existe")
    else:
        with usuario_file:
            pregunta=[]
            usuario_file.seek(0)
            lines=usuario_file.readlines()
            for i in range(len(lines)):
                line=lines[i].split(",")
                if name==line[0].strip():
                    if password==line[1].strip():
                        if line[3].strip()=="green":
                            try:
                                preguntas_=open("preguntas.txt", "r", encoding="utf-8" )
                            except:
                                print("el archivo no existe")
                            else:
                                with preguntas_:
                                 preguntas_.seek(0)
                                 line_p= preguntas_.readlines()
                                 for b in range (len(line_p)):
                                    if cat==0:
                                        a=randrange(0,9)
                                    else:
                                        a=randrange(10,19)
                                    pregunta.append(line_p[a])
                                    usuario_file.close()
                                    return f"{pregunta}"
    pass
                    
a=question(name,password,0)
print(a)