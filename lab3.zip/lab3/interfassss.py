
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
from tkinter import Tk,Canvas,Button,DISABLED,NORMAL
import trivia_client
from random import randint

url="http://localhost:80"
class interfazz(Tk):
    def __init__(self):
        super().__init__()
        self.resizable(False,False)
        self.title("preguntados")
        self.geometry("500x500")

        self.abrir_s = Button(text="Abrir sesion",command=self.abrir)
        self.abrir_s.grid(row=2,column=0,sticky="",pady=10)
        self.registrar_us = Button(text="Registrarse",command=self.registrar)
        self.registrar_us.grid(row=1,column=0,sticky="",pady=10)
        self.lista=Button(text="lista de usuarios conectados",command=self.listaa)
        self.lista.grid(row=3,column=0,sticky="",pady=10)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(10, weight=1)

    def registrar(self):

        self.abrir_s.grid_remove()
        self.registrar_us.grid_remove()
        self.lista.grid_remove()
        self.nombre = Label(text = "Nombre que desea registrar: ")
        self.contraseña = Label(text = "Contraseña que desea utilizar: ")
        self.nombre.grid(row = 0, column = 0, sticky = W, pady = 10)
        self.contraseña.grid(row = 1, column = 0, sticky = W, pady = 10)
        self.e_nombre = Entry()
        self.e_contraseña = Entry()
        self.e_nombre.grid(row = 0, column = 1, pady = 10)
        self.e_contraseña.grid(row = 1, column = 1, pady = 10)
        self.finalizar=Button(text = "Finalizar", command=self.registraa)
        self.finalizar.grid(row=4,column=0,sticky="", pady=10)
        self.grid_columnconfigure(10, weight=10)

    def registraa(self):

        nombre_global = self.e_nombre.get()
        contraseña_global=self.e_contraseña.get()
        self.nombre.destroy()
        self.contraseña.destroy()
        self.e_nombre.destroy()
        self.e_contraseña.destroy()
        self.finalizar.destroy()
        a= trivia_client.registerUser(url,nombre_global,contraseña_global)
        self.abrir_s.grid()
        self.registrar_us.grid()
        self.lista.grid()
        messagebox.showinfo("informacion", f"{a}")
        
    def listaa(self):
        self.abrir_s.grid_remove()
        self.registrar_us.grid_remove()
        self.lista.grid_remove()
        self.nombre = Label(text = "Nombre de usuario: ")
        self.contraseña = Label(text = "Contraseña: ")
        self.nombre.grid(row = 0, column = 0, sticky = W, pady = 10)
        self.contraseña.grid(row = 1, column = 0, sticky = W, pady = 10)
        self.e_nombre = Entry()
        self.e_contraseña = Entry()
        self.e_nombre.grid(row = 0, column = 1, pady = 10)
        self.e_contraseña.grid(row = 1, column = 1, pady = 10)
        self.finalizar=Button(text = "finalizar", command=self.obtener)
        self.finalizar.grid(row=4,column=0,sticky="", pady=10)
        
    def obtener(self):
        nombre_ = self.e_nombre.get()
        contraseña_=self.e_contraseña.get()
        self.nombre.destroy()
        self.contraseña.destroy()
        self.e_nombre.destroy()
        self.e_contraseña.destroy()
        self.finalizar.destroy()
        a=trivia_client.getList(url,nombre_,contraseña_).strip()
        self.usuarios_c = Label(text = f"{a}")
        self.usuarios_c.grid(row = 0, column = 0, sticky = W, pady = 10)
        self.fina=Button(text="finalizar",command=self.final)
        self.fina.grid(row=1,column=0,sticky="",pady=10)
        
    def final(self):
        self.usuarios_c.destroy()
        self.fina.destroy()
        self.abrir_s.grid()
        self.registrar_us.grid()
        self.lista.grid()
        
    def abrir(self):

        self.abrir_s.grid_remove()
        self.registrar_us.grid_remove()
        self.lista.grid_remove()
        self.nombre = Label(text = "Nombre de usuario: ")
        self.contraseña = Label(text = "Contraseña: ")
        self.nombre.grid(row = 0, column = 0, sticky = W, pady = 10)
        self.contraseña.grid(row = 1, column = 0, sticky = W, pady = 10)
        self.e_nombre = Entry()
        self.e_contraseña = Entry()
        self.e_nombre.grid(row = 0, column = 1, pady = 10)
        self.e_contraseña.grid(row = 1, column = 1, pady = 10)
        self.finalizar=Button(text = "Jugar", command=self.abrir_)
        self.finalizar.grid(row=4,column=0,sticky="", pady=10)
        self.grid_columnconfigure(10, weight=10)

    def abrir_(self):

        global nombre_global,contraseña_global
        nombre_global = self.e_nombre.get()
        contraseña_global=self.e_contraseña.get()
        self.nombre.destroy()
        self.contraseña.destroy()
        self.e_nombre.destroy()
        self.e_contraseña.destroy()
        self.finalizar.destroy()
        a=trivia_client.openSession(url,nombre_global,contraseña_global)
        print(f"{a}")
        self.abrir_s.grid()
        self.registrar_us.grid()
        self.lista.grid()
        if a=="ha iniciado sesion":
            app=ruleta(500,500)
            app.mainloop()
                   
class ruleta(Toplevel):
    def __init__(self,width,height):
        super().__init__()
        self.title("ruletaaa")
        self.geometry("500x420")
        #boton girar la ruleta
        self.button_comenzar=Button(self, text="girar",command=self.pulsar)
        self.button_comenzar.grid(row=3, column=0, columnspan=2)
        self.cerrar_j=Button(self,text="Cerrar juego",command=self.reinicio)
        self.cerrar_j.grid(row=4,column=0,columnspan=2)
        
        self.canvas= Canvas(self)
        self.canvas.grid(row=2, column=1)
        
        img_ruleta= Image.open("ruletaaaa.png")
        #tamaño de la imagen
        self.img_ruleta=img_ruleta.resize((int(width/2),int(height/2)))
        #convertir imagen a tkinter
        self.tk_img_ruleta= ImageTk.PhotoImage(self.img_ruleta, master=self)
        self.canvas.create_image(int(self.canvas.winfo_reqwidth()/2), int(self.canvas.winfo_reqheight()/2), image=self.tk_img_ruleta)
        self.angulo= 20
               
    def pulsar(self):
        global cat
        self.rotacion= randint(20,100)
        self.button_comenzar.config(state=DISABLED) 
        self.elim_rotacion=0.0
        if self.rotacion>=20 and self.rotacion<=26 or self.rotacion>35 and self.rotacion<=43 or self.rotacion>53 and self.rotacion<=61 or self.rotacion>71 and self.rotacion<79 or self.rotacion>88 and self.rotacion<=97:
            cat=1
        if self.rotacion>26 and self.rotacion<=35 or self.rotacion>43 and self.rotacion<=53 or self.rotacion>61 and self.rotacion<=71 or self.rotacion>79 and self.rotacion<=88 or self.rotacion>97 and self.rotacion<=100:
            cat=0
        self.girar()
         
    def girar(self):
        if self.elim_rotacion == self.rotacion:
            self.button_comenzar.config(state=NORMAL)
            self.elim()
            return
        
        self.rotacion_img=self.img_ruleta.rotate(self.angulo*self.elim_rotacion)
        self.tk_img_ruleta= ImageTk.PhotoImage(self.rotacion_img, master=self)
                
        # Update canvas with rotated image
        self.canvas.delete("all")
        self.canvas.create_image(int(self.canvas.winfo_reqwidth()/2), int(self.canvas.winfo_reqheight()/2), image=self.tk_img_ruleta)
        
        # Increment iterations counter
        self.elim_rotacion+=1
      
        # Animation by calling after
        self.after(33, self.girar)
       
    def elim(self):
            
            global au
            self.canvas.delete("all")
            self.button_comenzar.grid_remove()

            au=trivia_client.getQuestion(url, nombre_global, contraseña_global,cat).strip().split(",")
            self.pregunta = Label(self, text=f"Pregunta: {au[1]}", justify="center")
            self.pregunta.grid(row=0, column=0, columnspan=2, pady=10)
            self.pregunt = Label(self, text=f"Opciones: {au[2]}", justify="center")
            self.pregunt.grid(row=1, column=0, columnspan=2, pady=10)

            self.opcione_a = Button(self, text="a", command=self.respuesta_a)
            self.opcione_a.grid(row=2, column=0, sticky="", padx=5, pady=5)
            self.opcion_b = Button(self, text="b", command=self.respuesta_b)
            self.opcion_b.grid(row=2, column=1, sticky="", padx=5, pady=5)
            self.opcion_c = Button(self, text="c", command=self.respuesta_c)
            self.opcion_c.grid(row=2, column=2, sticky="", padx=5, pady=5)

    def respuesta_a(self):
        global r
        r=str
        self.pregunta.grid_remove()
        self.pregunt.grid_remove()
        self.opcione_a.grid_remove()
        self.opcion_b.grid_remove()
        self.opcion_c.grid_remove()
        r="a"
        self.com_res()
    def respuesta_b(self):
        global r
        r=str
        self.pregunta.grid_remove()
        self.pregunt.grid_remove()
        self.opcione_a.grid_remove()
        self.opcion_b.grid_remove()
        self.opcion_c.grid_remove()
        r="b"
        self.com_res()
    def respuesta_c(self):
        global r
        r=str
        self.pregunta.grid_remove()
        self.pregunt.grid_remove()
        self.opcione_a.grid_remove()
        self.opcion_b.grid_remove()
        self.opcion_c.grid_remove()
        r="c"
        self.com_res()
        
    def com_res(self):
        if r==au[3].strip():
                messagebox.showinfo("informacion", "felicidades por la respuesta correcta, 100 puntos")
                self.score=trivia_client.getScore(url,nombre_global,contraseña_global)
                self.score=int(self.score)
                self.score+=100
                print(trivia_client.updateScore(url,nombre_global,contraseña_global,self.score))
                messagebox.showinfo("informacion",f"su puntaje actual es de {self.score}")
                self.retorno(500,500)
        else:
            messagebox.showinfo("informacion", "respuesta incorrecta, -50 puntos")
            self.score=trivia_client.getScore(url,nombre_global,contraseña_global)
            self.score=int(self.score)
            self.score+=-50
            print(trivia_client.updateScore(url,nombre_global,contraseña_global,self.score))
            messagebox.showinfo("informacion",f"su puntaje actual es de {self.score}")
            self.retorno(500,500)
            
    def reinicio(self):
        ruleta.destroy(self)
        print(trivia_client.closeSession(url,nombre_global,contraseña_global))
        
    def retorno(self, width, height):
        self.button_comenzar.grid()
        self.canvas= Canvas(self)
        self.canvas.grid(row=2, column=1)
        
        img_ruleta= Image.open("ruletaaaa.png")
        #tamaño de la imagen
        self.img_ruleta=img_ruleta.resize((int(width/2),int(height/2)))
        #convertir imagen a tkinter
        self.tk_img_ruleta= ImageTk.PhotoImage(self.img_ruleta, master=self)
        self.canvas.create_image(int(self.canvas.winfo_reqwidth()/2), int(self.canvas.winfo_reqheight()/2), image=self.tk_img_ruleta)
        self.angulo= 20
                            
app = interfazz()
app.mainloop()