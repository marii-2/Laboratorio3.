import random 
from random import randrange
import json
# Se deben codificar las siguientes funciones y replicar la funcionalidad descrita en los comentarios
# Además, para la gestión de usuarios y preguntas se debe hacer uso de archivos
# La función recibe name y password
# Si el usuario ya existe deber retornar  "User already registered"
# Si el usuario no existe debe registrarlo y retornar  "User succesfully registered"
def registerUser(name,password):
    try:
     usuario_file=open("usuario", "a+") #abrir archivo
    except:
        return "El archivo no existe"
    else:
        with usuario_file:
            a=1 #variable que se utiliza despues
            usuario_file.seek(0) #.seek para establecer desde donde comienza el identificador del archivo
            lines= usuario_file.readlines() #guardar las lineas del archivo en una variable
                
            for i in range(len(lines)): #bucle for para comprobar si el usuario ya se encuantra registrado
                nombre=lines[i].split(",") #guardar la linea numero i en la variable nombre,.split()la vuelve una lista
                if nombre[0].strip()==name: #comprobar si el indexo cero en la linea i (que es el nombre) coincide con el nombre dado
                    a=0 #variable para controlar si se encuentra registrado el usuario no lo vuelva a registrar
                    break               
            if a==1:
                usuario_file.write(f"{name},{password},0,red\n")#Agrega el nombre y la contraseña del usuario
                usuario_file.close()
                return "Usuario registrado correctamente"
            else:
                usuario_file.close()
                return "El usuario ya esta registrado" 
    pass
# Función que abre o cierra una sesión
# Abre/cierra una sesión del usuario dependiendo del valor de flag 
# lo hace si el nombre de usuario y la contraseña son correctos
def openCloseSession(name,password,flag):
    def ayuda(lineas_c=[]): #funcion para reemplazar si el usuario esta conectado o no.
        help=open("usuario", "w")#abre el archivo
        help.writelines(lineas_c)  #sobre escribe las lineas
    try:
     usuario_file =open("usuario", "r")   
    except:
        print('El archivo no existe')
    else: 
        with usuario_file:
            a=2
            usuario_file.seek(0)#establecer desde donde se indexa el archivo
            lines= usuario_file.readlines()#guardar las lineas del archivo en una varianle
            lineas_c=[]#variable auxiliar para luego reeplazar las lineas que se modifican
            for i in range(len(lines)):#bucle for para comprobar el estado del usuario
                linea_i=lines[i].strip().split(",") #.strip()elimina los espacios en blnaco, .split()la vuelve una lista
                if linea_i[0].strip()==name:#compara si el nombre dado esta en la linea que se visualiza
                    if linea_i[1].strip()==password:#comprueba si la password esta en la linea que se visualiza
                        if linea_i[3]=="red":#comprueba el estado
                            lineas_c.append(f"{linea_i[0]},{linea_i[1]},{linea_i[2]},green\n")#cambia el estado y deja lo demas igual
                            a=0
                        if linea_i[3]=="green":#comprueba el estado
                            lineas_c.append(f"{name},{password},{linea_i[2]},red\n")#cambia de estado y deja lo demas igual
                            a=1
                    else:
                        lineas_c.append(lines[i])
                else:
                    lineas_c.append(lines[i])#para no reemplazar las lineas de el archivo que no se cambian
            ayuda(lineas_c)#llamar a la funcion
            if a==1:
                usuario_file.close()
                return "ha cerrado sesion"
            if a==0:
                usuario_file.close()
                return "ha iniciado sesion"
            else:
                usuario_file.close()
                return "la contraseña o el nombre de usuario es incorrecto"                     
    pass
# Función que actualiza el puntaje
# Actualiza el puntaje del usuario con el valor de score si el nombre de usuario y la contraseña 
# son correctos y si el usuario se encuentra con sesión abierta
def updateScore(name,password, score):
    lineas_c=[]
    def score_r(lineas_c):#funcion para reemplazar el puntaje nuevo
     ayuda=open("usuario", "w")
     ayuda.writelines(lineas_c)
    try:
     usuario_file =open("usuario", "r+")  
    except:
        print('El archivo no existe')
    else: 
        with usuario_file:
            a=1
            usuario_file.seek(0)#.seek() para indicar desde donde se inicia el index del archivo
            #variable de ayuda para luego reemplzar el nuevo puntaje
            lines= usuario_file.readlines()#guardar en una variable las lineas del archivo           
            for i in range(len(lines)):
                linea=lines[i].strip().split(",")#guardar la linea i en una variable eliminando los espacios y volviendola una lista
                if linea[0].strip()==name:#comparar si el nombre esta en la linea visualizada
                    if linea[1].strip()==password:#comprobar si la contraseña esta en la linea visualizada
                        if linea[3].strip()=="green":#comprobar el estado
                            lineas_c.append(f"{linea[0]},{linea[1]},{score},green\n")#guardar el nuevo puntaje en la variable de ayuda sin modificar los demas valores
                            a=0
                        else:
                           lineas_c.append(lines[i])    
                    else:
                        lineas_c.append(lines[i])
                else:
                    lineas_c.append(lines[i])#dejar como estan las lineas del archivo que no se modifican            
            score_r(lineas_c)#llamr la funcion 
            if a==0:
             usuario_file.close()
             return "Su puntaje ha sido actualizado"
            else:
                usuario_file.close()
                return "no se pudo actualizar el puntaje"           
    pass
# Retorna el puntaje del usuario si el nombre de usuario y la contraseña 
# son correctos y si el usuario se encuentra con sesión abierta
def getScore(name,password):
    try:
        usuario_file=open("usuario", "r")
    except:
        print("el archivo no existe")
    else:
        with usuario_file:
            usuario_file.seek(0)#indicar desde donde inicia el indexo del archivo
            lines=usuario_file.readlines()#guardar en una variable las lineas del archivo
            for i in range(len(lines)):
                linea=lines[i].strip().split(",")#guarda la linea i del archivo en una variable en forma de una lista y elimina los espacios innecesarios
                if linea[0].strip()==name:#comparacion
                    if linea[1].strip()==password:#comparacion
                        if linea[3]=="green":#comparacion del estado
                            usuario_file.close() 
                            return linea[2]#imprimir el puntaje actual 
    pass
# Función que lee la lista de usuarios conectados
# retorna una lista con los usuarios conectados, solo debe devolver nombre y puntaje
# si el nombre de usuario y la contraseña  son correctos y si el usuario se encuentra con sesión abierta
def usersList(name,password):
    try:
        usuario_file=open("usuario", "r")
    except:
        print("el archivo no existe")
    else:
        with usuario_file:
            j=[]
            a=0
            usuario_file.seek(0)
            lines=usuario_file.readlines()
            for i in range(len(lines)):
                linea=lines[i].split(",")
                if linea[0].strip()==name:
                    if linea[1].strip()==password:
                        if linea[3].strip()=="green":
                            for b in range(len(lines)):
                                linea_2=lines[b].split(",")
                                if linea_2[3].strip()=="green":
                                    j.append(f"{linea_2[0]},{linea_2[2]}\n")
                                    a=1                
                if a==1:
                    usuario_file.close()
                    return f"{j}"         
    pass    
# Función que genera una pregunta en una categoría cat
# retorna la pregunta si el nombre de usuario y la contraseña  son correctos y si el usuario se encuentra con sesión abierta
def question(name,password,cat):
    try:
        usuario_file= open("usuario", "r")
    except:
        print("el archivo no existe")
    else:
        with usuario_file:
            pregunta=[]
            usuario_file.seek(0)
            lines=usuario_file.readlines()
            for i in range(len(lines)):
                line=lines[i].split(",")
                if name==line[0].strip():
                    if password==line[1].strip():
                        if line[3].strip()=="green":
                            try:
                                preguntas_=open("preguntas.txt", "r", encoding="utf-8")
                            except:
                                print("el archivo no existe")
                            else:
                                with preguntas_:
                                 preguntas_.seek(0)
                                 line_p= preguntas_.readlines()
                                 for b in range (len(line_p)):
                                    if cat==0:
                                        a=randrange(0,9)
                                    else:
                                        a=randrange(10,19)
                                    pregunta.append(line_p[a])
                                    usuario_file.close()
                                    return f"{pregunta}"
                                        
        usuario_file.close()
    pass
                                     
                                 
                        
                        
                        
        
            
        
                                